# Data
Raw data is not committed. This project uses the public **Telco Customer Churn** dataset (Kaggle, IBM sample data).
Download it and save as `data/telco_churn.csv`.

Target column: `Churn` (Yes/No). Identifier column `customerID` is dropped before training.

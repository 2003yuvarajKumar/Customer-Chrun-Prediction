# Data Dictionary (Telco Customer Churn)
| Column | Description |
|---|---|
| customerID | Unique customer ID (dropped for modelling) |
| gender, SeniorCitizen, Partner, Dependents | Demographics |
| tenure | Months the customer has stayed |
| PhoneService, MultipleLines, InternetService | Services |
| OnlineSecurity, OnlineBackup, DeviceProtection, TechSupport, StreamingTV, StreamingMovies | Add-on services |
| Contract, PaperlessBilling, PaymentMethod | Account information |
| MonthlyCharges, TotalCharges | Billing amounts |
| Churn | Target: did the customer leave (Yes/No) |

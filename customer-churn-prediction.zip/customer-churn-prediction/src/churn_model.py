"""Customer churn prediction: cleaning, EDA plots, feature engineering, modelling, evaluation.

Usage: python src/churn_model.py --input data/telco_churn.csv
"""
import argparse
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (ConfusionMatrixDisplay, accuracy_score,
                             classification_report, precision_score, recall_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

RANDOM_STATE = 42


def clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.drop_duplicates().copy()
    df = df.drop(columns=["customerID"], errors="ignore")
    # TotalCharges has blank strings for brand-new customers
    df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
    df["TotalCharges"] = df["TotalCharges"].fillna(df["TotalCharges"].median())
    df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})
    return df


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    df["tenure_group"] = pd.cut(df["tenure"], [-1, 12, 24, 48, 72],
                                labels=["0-1y", "1-2y", "2-4y", "4-6y"]).astype(str)
    df["avg_monthly_spend"] = df["TotalCharges"] / df["tenure"].replace(0, 1)
    return df


def eda_plots(df: pd.DataFrame, out: Path):
    sns.countplot(data=df, x="Churn"); plt.title("Churn distribution")
    plt.savefig(out / "churn_distribution.png", dpi=150); plt.close()
    sns.countplot(data=df, x="Contract", hue="Churn"); plt.title("Churn by contract type")
    plt.savefig(out / "churn_by_contract.png", dpi=150); plt.close()
    sns.boxplot(data=df, x="Churn", y="tenure"); plt.title("Tenure vs churn")
    plt.savefig(out / "tenure_vs_churn.png", dpi=150); plt.close()


def build_pipeline(model, num_cols, cat_cols):
    pre = ColumnTransformer([
        ("num", StandardScaler(), num_cols),
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
    ])
    return Pipeline([("pre", pre), ("model", model)])


def evaluate(name, pipe, X_test, y_test, out: Path):
    pred = pipe.predict(X_test)
    metrics = {
        "model": name,
        "accuracy": accuracy_score(y_test, pred),
        "precision": precision_score(y_test, pred),
        "recall": recall_score(y_test, pred),
    }
    print(f"\n== {name} ==")
    print(classification_report(y_test, pred, target_names=["Stay", "Churn"]))
    ConfusionMatrixDisplay.from_predictions(y_test, pred)
    plt.title(f"Confusion matrix: {name}")
    plt.savefig(out / f"confusion_{name.replace(' ', '_').lower()}.png", dpi=150)
    plt.close()
    return metrics


def feature_importance(pipe, out: Path, top=15):
    names = pipe.named_steps["pre"].get_feature_names_out()
    imp = pipe.named_steps["model"].feature_importances_
    s = pd.Series(imp, index=names).nlargest(top).sort_values()
    s.plot(kind="barh", figsize=(8, 6)); plt.title("Top churn drivers (Random Forest)")
    plt.tight_layout(); plt.savefig(out / "feature_importance.png", dpi=150); plt.close()
    print("\nTop churn drivers:\n", s.sort_values(ascending=False).head(10))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="data/telco_churn.csv")
    ap.add_argument("--out", default="outputs")
    ap.add_argument("--models", default="models")
    args = ap.parse_args()
    out, models = Path(args.out), Path(args.models)
    out.mkdir(exist_ok=True); models.mkdir(exist_ok=True)

    df = add_features(clean(pd.read_csv(args.input)))
    eda_plots(df, out)

    X, y = df.drop(columns=["Churn"]), df["Churn"]
    num_cols = X.select_dtypes(include=np.number).columns.tolist()
    cat_cols = X.select_dtypes(exclude=np.number).columns.tolist()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE)

    candidates = {
        "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
        "Random Forest": RandomForestClassifier(n_estimators=300, class_weight="balanced",
                                                random_state=RANDOM_STATE, n_jobs=-1),
    }
    results, fitted = [], {}
    for name, model in candidates.items():
        pipe = build_pipeline(model, num_cols, cat_cols).fit(X_train, y_train)
        fitted[name] = pipe
        results.append(evaluate(name, pipe, X_test, y_test, out))

    res = pd.DataFrame(results).round(3)
    res.to_csv(out / "model_comparison.csv", index=False)
    print("\nModel comparison:\n", res.to_string(index=False))

    feature_importance(fitted["Random Forest"], out)
    best = res.sort_values("recall", ascending=False).iloc[0]["model"]
    joblib.dump(fitted[best], models / "churn_model.joblib")
    print(f"\nSaved best model by recall: {best}")


if __name__ == "__main__":
    main()

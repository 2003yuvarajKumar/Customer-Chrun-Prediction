# Customer Churn Prediction (Python, Machine Learning)

Predicts which telecom customers are likely to churn, and identifies the main drivers so a retention team can act on them.

## Highlights
- Data cleaning (duplicates, blank `TotalCharges`, target encoding)
- Exploratory data analysis with charts
- Feature engineering (`tenure_group`, `avg_monthly_spend`)
- Two models compared: Logistic Regression and Random Forest
- Evaluated with accuracy, precision, recall and confusion matrices
- Feature importance to show churn drivers

## Results
Run the script and paste your own numbers here (they are written to `outputs/model_comparison.csv`):

| Model | Accuracy | Precision | Recall |
|---|---|---|---|
| Logistic Regression | _fill in_ | _fill in_ | _fill in_ |
| Random Forest | _fill in_ | _fill in_ | _fill in_ |

**Business takeaways:** _write 2-3 bullet points from `outputs/feature_importance.png`, e.g. contract type, tenure, monthly charges._

## Project Structure
```
customer-churn-prediction/
├── data/            # dataset (not committed, see data/README.md)
├── docs/data_dictionary.md
├── models/          # saved model (not committed)
├── outputs/         # charts and metrics
├── src/churn_model.py
├── requirements.txt
└── LICENSE
```

## How to Run
```bash
git clone https://github.com/<your-username>/customer-churn-prediction.git
cd customer-churn-prediction
pip install -r requirements.txt
# put telco_churn.csv in data/
python src/churn_model.py --input data/telco_churn.csv
```

## Author
**Yuvaraj Kumar** | [LinkedIn](https://linkedin.com/in/yuvarajkumar-m) | yuvarajkumarm442@gmail.com
